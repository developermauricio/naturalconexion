<?php // phpcs:ignore Internal.NoCodeFound ?>
{{schema name="yoast/recipe-description" only-nested=true}}
{
	"name": {{html name="description"}}
}
