<div class="wrap">
    <h1><?php echo WPWOOF_SL_ITEM_NAME ?></h1>
</div>

<!-- div class="wpwoof-content-top wpwoof-box">
    <div class="">
        <h1>Help:</h1>
        <p><h3><strong> - Using the plugin for the first time? <a href="http://www.pixelyoursite.com/product-catalog-help" target="_blank">Click here for help</a></strong></h3></p>
    </div>
</div -->