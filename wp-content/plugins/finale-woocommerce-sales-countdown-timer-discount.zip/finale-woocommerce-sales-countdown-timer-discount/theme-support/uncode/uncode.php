<?php

add_action( 'wp', 'wcct_theme_helper_uncode', 99 );

function wcct_theme_helper_uncode() {

	$wcct_core = WCCT_Core()->appearance;

	//runs perfect
}
