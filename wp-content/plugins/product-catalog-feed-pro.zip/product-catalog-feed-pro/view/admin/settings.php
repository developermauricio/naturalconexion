<?php

$license 	= get_option( 'pcbpys_license_key' );
$status 	= get_option( 'pcbpys_license_status' );

if( $status !== false && $status == 'valid' && !isset($_GET['pcbpys_license_deactivate']) ) { 
    include('admin-settings.php');
} else {
    include('admin-settings.php');       }